<?php
/*******************************************
* Thank-o-matic
* Re-edited by Adk-Team
* www.smfpersonal.net
* 2009-2011
*******************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

//New Actions
function ThanYou_add_index_actions(&$actionArray)
{
	//Load Adkportal actions
	$actionArray += array(
		'thankyou' => array('ThankYouPost.php', 'ThankYou'),
		'thankyouajax' => array('ThankYouPost.php', 'ThankYouPostAJAX'),
		'thankyoupostlock' => array('ThankYouPost.php', 'ThankYouPostLock'),
		'thankyoupostlist' => array('ThankYouPost.php', 'ThankYouPostListShow'),
		'thankyoupostdelete' => array('ThankYouPost.php', 'ThankYouPostDelete'),
		'thankyoupostdm' => array('ThankYouPost.php', 'ThankYouPostDeletePost'),
		'thankyoupostcloseall' => array('ThankYouPost.php', 'ThankYouPostCloseAll'),
		'thankyoupostunlockall' => array('ThankYouPost.php', 'ThankYouPostUnlockAllPosts'),
	);
}

//Admin Areas
function ThanYou_add_admin_areas($adminAreas)
{
	global $txt;
	
	$adminAreas['config']['areas'] += array(
		'thankyoupostsettings' => array(
			'label' => $txt['thankyouposttitle'],
			'file' => 'ManageThankYouPost.php',
			'function' => 'ManageThankYouPost',
			'icon' => 'thank_you_settings.png',
			'subsections' => array(
				'general' => array($txt['general_settings']),
				'layout' => array($txt['mods_cat_layout']),
				'permission' => array($txt['edit_permissions'], 'enabled' => allowedTo('manage_permissions')),
				'boards' => array($txt['admin_boards']),
				'modrelated' => array($txt['thxmodification']),
			),
		),
	);
	
	$adminAreas['maintenance']['areas'] += array(
		'maintainThankYouPost' => array(
			'label' => $txt['maintain_thxpost'],
			'file' => 'ThankYouPost-Maintaince.php',
			'icon' => 'thank_you_maintain.png',
			'function' => 'ManageMaintenanceThankYouPost',
			'subsections' => array(
				'maintain' => array($txt['maintain_thank_you_post_maintainaince'], 'admin_forum'),
				'recount' => array($txt['maintain_thank_you_post_recount'], 'admin_forum'),
			),
		),
	);
}

//Function ThankYou_add_profile_areas
function ThankYou_add_profile_areas($profileAreas)
{
	global $txt;
	
	$profileAreas['info']['areas'] += array(
		'showThankYouPosts' => array(
			'label' => $txt['thankyoutitle'],
			'file' => 'Profile-ThankYouPost.php',
			'function' => 'showThankYouPosts',
			'subsections' => array(
				'messages' => array($txt['thankyou_messages_become'], 'profile_view_any'),
				'topics' => array($txt['thankyou_topics_become'], 'profile_view_any'),
				'messages_given' => array($txt['thankyou_messages_given'], 'profile_view_any'),
				'topics_given' => array($txt['thankyou_topics_given'], 'profile_view_any'),
			),
			'permission' => array(
				'own' => array('profile_view_own'),
				'any' => array('profile_view_any'),
			)
		),
	);
}

function ThankYou_add_profile_modify($p)
{
	global $txt;
	
	$p += array(
		'thank_you_post_made' =>  array(
			'type' => 'callback',
			'callback_func' => 'thank_you_post_modify',
			'subtext' => $txt['thankyoutitle'],
			'permission' => 'admin_forum',
			// Set thank_you_post_became too!
			'input_validate' => create_function('&$value', '
				global $profile_vars, $cur_profile;

				$value = (int) $value;
				if (isset($_POST[\'thank_you_post_became\']))
				{
					$profile_vars[\'thank_you_post_became\'] = $_POST[\'thank_you_post_became\'] != \'\' ? (int) $_POST[\'thank_you_post_became\'] : "\'\'";
					$cur_profile[\'thank_you_post_became\'] = $_POST[\'thank_you_post_became\'] != \'\' ? (int) $_POST[\'thank_you_post_became\'] : \'\';
				}
				return true;
			'),
			'preload' => create_function('', '
				global $context, $cur_profile;

				$context[\'member\'][\'thank_you_post\'][\'became\'] = $cur_profile[\'thank_you_post_became\'];
				$context[\'member\'][\'thank_you_post\'][\'made\'] = $cur_profile[\'thank_you_post_made\'];

				return true;
			'),
			'enabled' => true,
		),
	);
}

//Index.template.php function
// A Output for the Thank You list, it's used for the Single Preview and Display Template :)
function template_thank_you_post($thankYouPost, $id_msg)
{
	global $txt, $context, $modSettings;
        echo '
					<span class="topslice"><span></span></span>';
	
	echo '<div class="poster_thank">';
					
	if (!empty($context['thank_you_post'][$id_msg]))
	{
		if(empty($context['thank_you_post_template']['disable_start_text']))
			echo '
									<div class="poster" id="thank_you_start_text"><h4>', $context['thank_you_post_template']['start_text'] , '</h4></div>';

		// Output the Thank You List...
		echo '
									<div class="postarea" id="thank_you_list">';

		foreach ($context['thank_you_post'][$id_msg]['fulllist'] as $thx)
			echo $thx['link'] , (!empty($thx['deletelink']) ? $thx['deletelink'] : '').($thx['last'] ? '' : ', ');

		echo '
									</div>';
	}

	// Counter and Link to the direct or a link to the complete list :)
	if (empty($context['thank_you_post_template']['disable_counter_text']))
	{
		echo '
									<div class="postarea" id="thank_you_list_link">';
		if (empty($context['thank_you_post_template']['disable_counter_link']))
			echo '
										<a href="', $thankYouPost['href'] ,'">';
		echo '
											', $txt['thank_you_link_beforecounter'], ' <strong>', $thankYouPost['counter'], '</strong> ', ($thankYouPost['counter'] == 1 ? $txt['thank_you_link_member'] : $txt['thank_you_link_members']).' '.($thankYouPost['counter'] == 1 ? $txt['thank_you_link_aftercounter'] : $txt['thank_you_link_aftercounters']);
		if (empty($context['thank_you_post_template']['disable_counter_link']))
			echo '
										</a>';
		echo '
									</div>';
	}

	// Show some information if the Thank-O-Matic Post is locked
	if ($thankYouPost['locked'])
		echo '
									<div class="postarea" id="thank_you_lock_text">', $txt['thank_you_is_locked'], '</div>';

  echo '</div>';
									
						 echo '
					<span class="botslice"><span></span></span>';
							
}

function ThankYou_add_display_buttons($normal_buttons)
{
	global $context, $scripturl, $txt;
	
	// Special Lock for the Thank You :)
	if ($context['thank_you_lock_allowed'])
		if (empty($context['is_thank_you_post_locked']))
			$normal_buttons['thankyoupostlock'] = array('text' => 'thank_you_post_lock_all_b', 'image' => 'thank_you_lock1.png', 'lang' => true, 'url' => $scripturl . '?action=thankyoupostcloseall;topic='  . $context['current_topic']);
		else
			$normal_buttons['thankyoupostlock'] = array('text' => 'thank_you_post_open_all_b', 'image' => 'thank_you_lock2.png', 'lang' => true, 'url' => $scripturl . '?action=thankyoupostcloseall;topic='  . $context['current_topic']);
	// A Fix for later, if some Translations are not Updated
	if (empty($txt['thank_you_link_aftercounters']))
		$txt['thank_you_link_aftercounters'] = $txt['thank_you_link_aftercounter'];
}

// Call the Thank-O-Matic Function.
function loadThankYouTemplateFunctions()
{
	global $context;
	
	// Assume if is allready setup, but check something before ;)
	if (!empty($context['call_thank_you_post_func']))
		return true;

	// I try to find if the function is loaded, and if it loaded try to find out if the function exists :)
	// Define the standard :)
	$context['call_thank_you_post_func'] = 'callback_template_thank_you_post';

	if (function_exists('template_thank_you_post'))
		$context['call_thank_you_post_func'] = 'template_thank_you_post';
}

// This is the last check before you can call a diffrent function!
function callback_template_thank_you_post($thankYouPost, $id_msg)
{
	global $context, $sourcedir;
	
	// This is the last test if the Standard Function exists!
	if ($context['call_thank_you_post_func'] != 'callback_template_thank_you_post' && function_exists($context['call_thank_you_post_func']))
		return $context['call_thank_you_post_func']($thankYouPost, $id_msg);
	elseif (function_exists('template_thank_you_post'))
		return template_thank_you($thankYouPost, $id_msg)	;

	// This is the master function that will work evertime!
	require_once($sourcedir . '/ThankYouPost.php');
	return backup_template_thank_you_post($thankYouPost, $id_msg);
}

?>