<?php
/*******************************************
* Thank-o-matic
* Re-edited by Adk-Team
* www.smfpersonal.net
* 2009-2011
*******************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

//Show the list of User who say thank you... this will be now in a new style... the old way have to many bugs in it :D
function template_main()
{
	global $settings;
	
	$themedir = basename($settings['theme_dir']);
	
	// Sorry i use a trick here, if you need to costumize this for other themes... than you need to that...
	// Later i will add this to the theme itself...
	if ($themedir == 'core')
		template_main_thank_you_core();
	else
		template_main_thank_you_curve();
}

function template_main_thank_you_curve()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

	// Show the topic information - icon, subject, etc.
	echo '
			<div id="forumposts">
				<div class="cat_bar"><h3 class="catbg">
					<img src="', $settings['images_url'], '/topic/', $context['class'], '.gif" align="bottom" alt="" />
					<span id="author">', $txt['author'], '</span>
					<span id="top_subject">', $txt['topic'], ': ', $context['subject'], ' &nbsp;(', $txt['read'], ' ', $context['num_views'], ' ', $txt['times'], ')</span>
				</h3></div>';

	// AJAX Style Thank You Post
	if (!empty($modSettings['thankYouPostAJAX']))
	{
		echo '
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var thank_you_ajax_url = smf_scripturl + \'?action=thankyouajax;topic=' . $context['current_topic'] . '\';

		function thankyou(msg_id) {
			// Follow the link if no ajax support...
			if (!window.XMLHttpRequest)
				return true;

			// Standard Variables
			var elementName = "ThankOMaticID" + msg_id;
			var elementButton = "buttonThxID" + msg_id;
			var elementLockButton = "thank_lock_button_" + msg_id;
			var elementDeleteButton = "thank_delete_button_" + msg_id;

			// Tell him that something loading :)
			ajax_indicator(true);

			// Remove the Thank You Button :)
			document.getElementById(elementButton).style.display = "none";
			document.getElementById(elementLockButton).style.display = "none";
			document.getElementById(elementDeleteButton).style.display = "none";

			var thank_you_ajax_thx = thank_you_ajax_url + ";sa=thx;msg=" + msg_id;
			var data = ThankYouLoadTextData(thank_you_ajax_thx, elementName, elementButton, elementDeleteButton, elementLockButton);

			return !data;
		}

		function ThankYouLoadTextData(url, elementName, elementButton, elementDeleteButton, elementLockButton) {
			if (!window.XMLHttpRequest)
				return false;

			request = new XMLHttpRequest();
			request.onreadystatechange = function() {
				if (request.readyState != 4)
					return;
				if (request.responseText != null && request.status == 200) {
					if (request.responseText.substr(0, 7) == "#ERROR#") {
						setInnerHTML(document.getElementById("Error" + elementName), request.responseText.substr(7));
						document.getElementById(elementButton).style.display = "inline";
						document.getElementById(elementLockButton).style.display = "none";
						document.getElementById(elementDeleteButton).style.display = "none";
						ajax_indicator(false);
					}
					else {
						document.getElementById(elementName).style.display = "block";
						setInnerHTML(document.getElementById(elementName), request.responseText);
						document.getElementById(elementButton).style.display = "none";
						document.getElementById(elementLockButton).style.display = "inline";
						document.getElementById(elementDeleteButton).style.display = "inline";
						ajax_indicator(false);
					}
					return false;
				}
				else {
					return true;
				}
			}
			// Load the Request!
			request.open("GET", url, true);
			request.send(null);
			return request;
		}
	// ]]></script>';
	}

	$ignoredMsgs = array();
	$alternate = false;

	// Get all the messages...
	if(!empty($context['thank_you_post']['post']))
	{
		$message = $context['thank_you_post']['post'];
		$ignoring = false;
		$alternate = !$alternate;
		if ($message['can_remove'])
			$removableMessageIDs[] = $message['id'];

		// Are we ignoring this message?
		if (!empty($message['is_ignored']))
		{
			$ignoring = true;
			$ignoredMsgs[] = $message['id'];
		}

		// Show the message anchor and a "new" anchor if this message is new.
		if ($message['id'] != $context['first_message'])
			echo '
					<a id="msg', $message['id'], '"></a>', $message['first_new'] ? '<a id="new"></a>' : '';

		echo '
				<div class="', $message['approved'] ? ($message['alternate'] == 0 ? 'windowbg' : 'windowbg2') : 'approvebg', '">
					<span class="topslice"><span></span></span>
					<div class="post_wrapper">';

		// Show information about the poster of this message.
		echo '
						<div class="poster">
							<h4>';

		// Show online and offline buttons?
		if (!empty($modSettings['onlineEnable']) && !$message['member']['is_guest'])
			echo '
								', $context['can_send_pm'] ? '<a href="' . $message['member']['online']['href'] . '" title="' . $message['member']['online']['label'] . '">' : '', '<img src="', $message['member']['online']['image_href'], '" alt="', $message['member']['online']['text'], '" />', $context['can_send_pm'] ? '</a>' : '';

		// Show a link to the member's profile.
		echo '
								', $message['member']['link'], '
							</h4>
							<ul class="reset smalltext" id="msg_', $message['id'], '_extra_info">';

		// Show the member's custom title, if they have one.
		if (!empty($message['member']['title']))
			echo '
								<li class="title">', $message['member']['title'], '</li>';

		// Show the member's primary group (like 'Administrator') if they have one.
		if (!empty($message['member']['group']))
			echo '
								<li class="membergroup">', $message['member']['group'], '</li>';

		// Don't show these things for guests.
		if (!$message['member']['is_guest'])
		{
			// Show the post group if and only if they have no other group or the option is on, and they are in a post group.
			if ((empty($settings['hide_post_group']) || $message['member']['group'] == '') && $message['member']['post_group'] != '')
				echo '
								<li class="postgroup">', $message['member']['post_group'], '</li>';
			echo '
								<li class="stars">', $message['member']['group_stars'], '</li>';

			// Show some Thank-O-Matic Stats ;D
			if (!empty($modSettings['thankYouPostDisplayPage']) && (empty($modSettings['thankYouPostDisplayDisableBecame']) || empty($modSettings['thankYouPostDisplayDisableMade'])))
			{
				echo '
								<li>', $txt['thank_you_post_thx_display'], '</li>';
				// Disabled?
				if(empty($modSettings['thankYouPostDisplayDisableMade']))
					echo '
								<li>-', $txt['thank_you_post_made_display'], ': ', $message['member']['thank_you_post']['made'], '</li>';

				// Disabled?
				if(empty($modSettings['thankYouPostDisplayDisableBecame']))
					echo '
								<li>-', $txt['thank_you_post_became_display'], ': ', $message['member']['thank_you_post']['became'], '</li>';
			}

			// Show avatars, images, etc.?
			if (!empty($settings['show_user_images']) && empty($options['show_no_avatars']) && !empty($message['member']['avatar']['image']))
				echo '
								<li class="avatar" style="overflow: auto;">
									<a href="', $scripturl, '?action=profile;u=', $message['member']['id'], '">
										', $message['member']['avatar']['image'], '
									</a>
								</li>';

			// Show how many posts they have made.
			if (!isset($context['disabled_fields']['posts']))
				echo '
								<li class="postcount">', $txt['member_postcount'], ': ', $message['member']['posts'], '</li>';

			// Is karma display enabled?  Total or +/-?
			if ($modSettings['karmaMode'] == '1')
				echo '
								<li class="karma">', $modSettings['karmaLabel'], ' ', $message['member']['karma']['good'] - $message['member']['karma']['bad'], '</li>';
			elseif ($modSettings['karmaMode'] == '2')
				echo '
								<li class="karma">', $modSettings['karmaLabel'], ' +', $message['member']['karma']['good'], '/-', $message['member']['karma']['bad'], '</li>';

			// Is this user allowed to modify this member's karma?
			if ($message['member']['karma']['allow'])
				echo '
								<li class="karma_allow">
									<a href="', $scripturl, '?action=modifykarma;sa=applaud;uid=', $message['member']['id'], ';topic=', $context['current_topic'], '.' . $context['start'], ';m=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $modSettings['karmaApplaudLabel'], '</a>
									<a href="', $scripturl, '?action=modifykarma;sa=smite;uid=', $message['member']['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';m=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $modSettings['karmaSmiteLabel'], '</a>
								</li>';

			// Show the member's gender icon?
			if (!empty($settings['show_gender']) && $message['member']['gender']['image'] != '' && !isset($context['disabled_fields']['gender']))
				echo '
								<li class="gender">', $txt['gender'], ': ', $message['member']['gender']['image'], '</li>';

			// Show their personal text?
			if (!empty($settings['show_blurb']) && $message['member']['blurb'] != '')
				echo '
								<li class="blurb">', $message['member']['blurb'], '</li>';

			// Any custom fields to show as icons?
			if (!empty($message['member']['custom_fields']))
			{
				$shown = false;
				foreach ($message['member']['custom_fields'] as $custom)
				{
					if ($custom['placement'] != 1 || empty($custom['value']))
						continue;
					if (empty($shown))
					{
						$shown = true;
						echo '
								<li class="im_icons">
									<ul>';
					}
					echo '
										<li>', $custom['value'], '</li>';
				}
				if ($shown)
					echo '
									</ul>
								</li>';
			}

			// This shows the popular messaging icons.
			if ($message['member']['has_messenger'] && $message['member']['can_view_profile'])
				echo '
								<li class="im_icons">
									<ul>
										', !empty($message['member']['icq']['link']) ? '<li>' . $message['member']['icq']['link'] . '</li>' : '', '
										', !empty($message['member']['msn']['link']) ? '<li>' . $message['member']['msn']['link'] . '</li>' : '', '
										', !empty($message['member']['aim']['link']) ? '<li>' . $message['member']['aim']['link'] . '</li>' : '', '
										', !empty($message['member']['yim']['link']) ? '<li>' . $message['member']['yim']['link'] . '</li>' : '', '
									</ul>
								</li>';

			// Show the profile, website, email address, and personal message buttons.
			if ($settings['show_profile_buttons'])
			{
				echo '
								<li class="profile">
									<ul>';
				// Don't show the profile button if you're not allowed to view the profile.
				if ($message['member']['can_view_profile'])
					echo '
										<li><a href="', $message['member']['href'], '">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/icons/profile_sm.gif" alt="' . $txt['view_profile'] . '" title="' . $txt['view_profile'] . '" border="0" />' : $txt['view_profile']), '</a></li>';

				// Don't show an icon if they haven't specified a website.
				if ($message['member']['website']['url'] != '' && !isset($context['disabled_fields']['website']))
					echo '
										<li><a href="', $message['member']['website']['url'], '" title="' . $message['member']['website']['title'] . '" target="_blank" class="new_win">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/www_sm.gif" alt="' . $message['member']['website']['title'] . '" border="0" />' : $txt['www']), '</a></li>';

				// Don't show the email address if they want it hidden.
				if (in_array($message['member']['show_email'], array('yes', 'yes_permission_override', 'no_through_forum')))
					echo '
										<li><a href="', $scripturl, '?action=emailuser;sa=email;msg=', $message['id'], '" rel="nofollow">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt['email'] . '" title="' . $txt['email'] . '" />' : $txt['email']), '</a></li>';

				// Since we know this person isn't a guest, you *can* message them.
				if ($context['can_send_pm'])
					echo '
										<li><a href="', $scripturl, '?action=pm;sa=send;u=', $message['member']['id'], '" title="', $message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline'], '">', $settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/im_' . ($message['member']['online']['is_online'] ? 'on' : 'off') . '.gif" alt="' . ($message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline']) . '" border="0" />' : ($message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline']), '</a></li>';

				echo '
									</ul>
								</li>';
			}

			// Any custom fields for standard placement?
			if (!empty($message['member']['custom_fields']))
			{
				foreach ($message['member']['custom_fields'] as $custom)
					if (empty($custom['placement']) || empty($custom['value']))
						echo '
								<li class="custom">', $custom['title'], ': ', $custom['value'], '</li>';
			}

			// Are we showing the warning status?
			if ($message['member']['can_see_warning'])
				echo '
								<li class="warning">', $context['can_issue_warning'] ? '<a href="' . $scripturl . '?action=profile;area=issuewarning;u=' . $message['member']['id'] . '">' : '', '<img src="', $settings['images_url'], '/warning_', $message['member']['warning_status'], '.gif" alt="', $txt['user_warn_' . $message['member']['warning_status']], '" />', $context['can_issue_warning'] ? '</a>' : '', '<span class="warn_', $message['member']['warning_status'], '">', $txt['warn_' . $message['member']['warning_status']], '</span></li>';
		}
		// Otherwise, show the guest's email.
		elseif (in_array($message['member']['show_email'], array('yes', 'yes_permission_override', 'no_through_forum')))
			echo '
								<li class="email"><a href="', $scripturl, '?action=emailuser;sa=email;msg=', $message['id'], '" rel="nofollow">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt['email'] . '" title="' . $txt['email'] . '" border="0" />' : $txt['email']), '</a></li>';

		// Done with the information about the poster... on to the post itself.
		echo '
							</ul>
						</div>
						<div class="postarea">
							<div class="flow_hidden">
								<div class="keyinfo">
									<div class="messageicon">
										<img src="', $message['icon_url'] . '" alt="" border="0"', $message['can_modify'] ? ' id="msg_icon_' . $message['id'] . '"' : '', ' />
									</div>
									<h5 id="subject_', $message['id'], '">
										<a href="', $message['href'], '" rel="nofollow">', $message['subject'], '</a>
									</h5>
									<div class="smalltext">&#171; <strong>', !empty($message['counter']) ? $txt['reply_noun'] . ' #' . $message['counter'] : '', ' ', $txt['on'], ':</strong> ', $message['time'], ' &#187;</div>
									<div id="msg_', $message['id'], '_quick_mod"></div>
								</div>';

		// If this is the first post, (#0) just say when it was posted - otherwise give the reply #.
		if ($message['can_approve'] || $context['can_reply'] || $message['can_modify'] || $message['can_remove'] || $context['can_split'] || $context['can_restore_msg'])
			echo '
								<ul class="reset smalltext quickbuttons">';
		// Thank-O-Matic need an reset sometimes... on special cases :D
		elseif (($message['thank_you_post']['post'] && !$message['thank_you_post']['locked']) || (($message['thank_you_post']['lock'] || $message['thank_you_post']['delete']) && $message['thank_you_post']['isThankYouPost']))
			echo '
								<ul class="reset smalltext quickbuttons">';

		// Maybe we can approve it, maybe we should?
		if ($message['can_approve'])
			echo '
									<li class="approve_button"><a href="', $scripturl, '?action=moderate;area=postmod;sa=approve;topic=', $context['current_topic'], '.', $context['start'], ';msg=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['approve'], '</a></li>';

		// Can they reply? Have they turned on quick reply?
		if ($context['can_reply'] && !empty($options['display_quick_reply']))
			echo '
									<li class="quote_button"><a href="', $scripturl, '?action=post;quote=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';num_replies=', $context['num_replies'], '" onclick="return oQuickReply.quote(', $message['id'], ');">', $txt['quote'], '</a></li>';

		// So... quick reply is off, but they *can* reply?
		elseif ($context['can_reply'])
			echo '
									<li class="quote_button"><a href="', $scripturl, '?action=post;quote=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';num_replies=', $context['num_replies'], '">', $txt['quote'], '</a></li>';

		// Can the user modify the contents of this post?
		if ($message['can_modify'])
			echo '
									<li class="modify_button"><a href="', $scripturl, '?action=post;msg=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], '">', $txt['modify'], '</a></li>';

		// How about... even... remove it entirely?!
		if ($message['can_remove'])
			echo '
									<li class="remove_button"><a href="', $scripturl, '?action=deletemsg;topic=', $context['current_topic'], '.', $context['start'], ';msg=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_message'], '?\');">', $txt['remove'], '</a></li>';

		// What about splitting it off the rest of the topic?
		if ($context['can_split'] && !empty($context['num_replies']))
			echo '
									<li class="split_button"><a href="', $scripturl, '?action=splittopics;topic=', $context['current_topic'], '.0;at=', $message['id'], '">', $txt['split'], '</a></li>';

		// Can do some Thank You Post things :)
		if ($message['thank_you_post']['post'] && !$message['thank_you_post']['locked'])
		{
			echo '
					<li class="thank_you_button"><span id="buttonThxID' . $message['id'] . '" style="display: inline;"><a id="buttonThxHrefID' . $message['id'] . '" href="', $scripturl, '?action=thankyou;topic=', $context['current_topic'], '.0;msg=', $message['id'], '"'.(!empty($modSettings['thankYouPostAJAX']) ? ' onclick="return thankyou(' . $message['id'] . ');"' : '').'>', $txt['thank_you_post_post_b'], '</a></span></li>';

			if(!empty($modSettings['thankYouPostAJAX']) && $context['browser']['is_ie']) {
			// I HATE INTERNET EXPLORER!!!!!!!!!!!!!!!!!!!!!!!
			echo '
				<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
					// Rewrite the url :x so that internet explorer can not follow it
					document.getElementById("buttonThxHrefID' . $message['id'] . '").href = "#msg=' . $message['id'] . '";
				// ]]></script>';
			}
		}
		if ($message['thank_you_post']['lock'] && $message['thank_you_post']['isThankYouPost'])
			echo '
					<li class="', $message['thank_you_post']['locked'] ? 'thank_you_open_button' : 'thank_you_lock_button', '"><a href="', $scripturl, '?action=thankyoupostlock;topic=', $context['current_topic'], '.0;msg=', $message['id'], '">', $message['thank_you_post']['locked'] ? $txt['thank_you_post_open_b'] : $txt['thank_you_post_lock_b'], '</a></li>';
		elseif ($message['thank_you_post']['lock'] && !$message['thank_you_post']['isThankYouPost'] && !empty($modSettings['thankYouPostAJAX']) && empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<li class="', $message['thank_you_post']['locked'] ? 'thank_you_open_button' : 'thank_you_lock_button', '" id="thank_lock_button_' . $message['id'] . '" style="display: none;"><a href="', $scripturl, '?action=thankyoupostlock;topic=', $context['current_topic'], '.0;msg=', $message['id'], '">', $message['thank_you_post']['locked'] ? $txt['thank_you_post_open_b'] : $txt['thank_you_post_lock_b'], '</a></li>';
		// This will prevent Java Script errors on most browser...
		elseif (!empty($modSettings['thankYouPostAJAX']) || !empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<span id="thank_lock_button_' . $message['id'] . '" style="display: none;"></span>';

		if ($message['thank_you_post']['delete'] && $message['thank_you_post']['isThankYouPost'])
			echo '
					<li class="thank_you_delete_button"><a href="', $scripturl, '?action=thankyoupostdelete;topic=', $context['current_topic'], '.0;msg=', $message['id'], ';sesc=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_thank_you_post'], '?\');">', $txt['thank_you_post_delete_b'], '</a></li>';
		elseif ($message['thank_you_post']['delete'] && !$message['thank_you_post']['isThankYouPost'] && !empty($modSettings['thankYouPostAJAX']) && empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<li class="thank_you_delete_button" id="thank_delete_button_' . $message['id'] . '" style="display: none;"><a href="', $scripturl, '?action=thankyoupostdelete;topic=', $context['current_topic'], '.0;msg=', $message['id'], ';sesc=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_thank_you_post'], '?\');">', $txt['thank_you_post_delete_b'], '</a></li>';
		// This will prevent Java Script errors on most browser...
		elseif (!empty($modSettings['thankYouPostAJAX']) || !empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<span id="thank_delete_button_' . $message['id'] . '" style="display: none;"></span>';

		// Can we restore topics?
		if ($context['can_restore_msg'])
			echo '
									<li class="restore_button"><a href="', $scripturl, '?action=restoretopic;msgs=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['restore_message'], '</a></li>';

		// Show a checkbox for quick moderation?
		if (!empty($options['display_quick_mod']) && $options['display_quick_mod'] == 1 && $message['can_remove'])
			echo '
									<li class="inline_mod_check" style="display: none;" id="in_topic_mod_check_', $message['id'], '"></li>';

		if ($message['can_approve'] || $context['can_reply'] || $message['can_modify'] || $message['can_remove'] || $context['can_split'] || $context['can_restore_msg'])
			echo '
								</ul>';
		// Thank-O-Matic okay close the ul on sometimes :D 
		elseif (($message['thank_you_post']['post'] && !$message['thank_you_post']['locked']) || (($message['thank_you_post']['lock'] || $message['thank_you_post']['delete']) && $message['thank_you_post']['isThankYouPost']))
			echo '
								</ul>';

		echo '
							</div>';

		// Ignoring this user? Hide the post.
		if ($ignoring)
			echo '
							<div id="msg_', $message['id'], '_ignored_prompt">
								', $txt['ignoring_user'], '
								<a href="#" id="msg_', $message['id'], '_ignored_link" style="display: none;">', $txt['show_ignore_user_post'], '</a>
							</div>';

		// Show the post itself, finally!
		echo '
							<div class="post">';

		if (!$message['approved'] && $message['member']['id'] != 0 && $message['member']['id'] == $context['user']['id'])
			echo '
								<div class="approve_post">
									', $txt['post_awaiting_approval'], '
								</div>';
		echo '
								<div class="inner" id="msg_', $message['id'], '"', '>', $message['body'], '</div>
							</div>';

		// Can the user modify the contents of this post?  Show the modify inline image.
		if ($message['can_modify'])
			echo '
							<img src="', $settings['images_url'], '/icons/modify_inline.gif" alt="" title="', $txt['modify_msg'], '" class="modifybutton" id="modify_button_', $message['id'], '" style="cursor: ', ($context['browser']['is_ie5'] || $context['browser']['is_ie5.5'] ? 'hand' : 'pointer'), '; display: none;" onclick="oQuickModify.modifyMsg(\'', $message['id'], '\')" />';

		// Assuming there are attachments...
		if (!empty($message['attachment']))
		{
			echo '
							<div id="msg_', $message['id'], '_footer" class="attachments smalltext">
								<div style="overflow: ', $context['browser']['is_firefox'] ? 'visible' : 'auto', ';">';

			$last_approved_state = 1;
			foreach ($message['attachment'] as $attachment)
			{
				// Show a special box for unapproved attachments...
				if ($attachment['is_approved'] != $last_approved_state)
				{
					$last_approved_state = 0;
					echo '
									<fieldset>
										<legend>', $txt['attach_awaiting_approve'], '&nbsp;[<a href="', $scripturl, '?action=attachapprove;sa=all;mid=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['approve_all'], '</a>]</legend>';
				}

				if ($attachment['is_image'])
				{
					if ($attachment['thumbnail']['has_thumb'])
						echo '
										<a href="', $attachment['href'], ';image" id="link_', $attachment['id'], '" onclick="', $attachment['thumbnail']['javascript'], '"><img src="', $attachment['thumbnail']['href'], '" alt="" id="thumb_', $attachment['id'], '" border="0" /></a><br />';
					else
						echo '
										<img src="' . $attachment['href'] . ';image" alt="" width="' . $attachment['width'] . '" height="' . $attachment['height'] . '" border="0" /><br />';
				}
				echo '
										<a href="' . $attachment['href'] . '"><img src="' . $settings['images_url'] . '/icons/clip.gif" align="middle" alt="*" border="0" />&nbsp;' . $attachment['name'] . '</a> ';

				if (!$attachment['is_approved'])
					echo '
										[<a href="', $scripturl, '?action=attachapprove;sa=approve;aid=', $attachment['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['approve'], '</a>]&nbsp;|&nbsp;[<a href="', $scripturl, '?action=attachapprove;sa=reject;aid=', $attachment['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['delete'], '</a>] ';
				echo '
										(', $attachment['size'], ($attachment['is_image'] ? ', ' . $attachment['real_width'] . 'x' . $attachment['real_height'] . ' - ' . $txt['attach_viewed'] : ' - ' . $txt['attach_downloaded']) . ' ' . $attachment['downloads'] . ' ' . $txt['attach_times'] . '.)<br />';
			}

			// If we had unapproved attachments clean up.
			if ($last_approved_state == 0)
				echo '
									</fieldset>';

			echo '
								</div>
							</div>';
		}

		echo '
						</div>
						<div class="moderatorbar">
							<div class="smalltext modified" id="modified_', $message['id'], '">';

		// Show "� Last Edit: Time by Person �" if this post was edited.
		if ($settings['show_modify'] && !empty($message['modified']['name']))
			echo '
								&#171; <em>', $txt['last_edit'], ': ', $message['modified']['time'], ' ', $txt['by'], ' ', $message['modified']['name'], '</em> &#187;';

		echo '
							</div>
							<div class="smalltext reportlinks">';

		// Maybe they want to report this post to the moderator(s)?
		if ($context['can_report_moderator'])
			echo '
								<a href="', $scripturl, '?action=reporttm;topic=', $context['current_topic'], '.', $message['counter'], ';msg=', $message['id'], '">', $txt['report_to_mod'], '</a> &nbsp;';

		// Can we issue a warning because of this post?  Remember, we can't give guests warnings.
		if ($context['can_issue_warning'] && !$message['is_message_author'] && !$message['member']['is_guest'])
			echo '
								<a href="', $scripturl, '?action=profile;area=issuewarning;u=', $message['member']['id'], ';msg=', $message['id'], '"><img src="', $settings['images_url'], '/warn.gif" alt="', $txt['issue_warning_post'], '" title="', $txt['issue_warning_post'], '" border="0" /></a>';
		echo '
								<img src="', $settings['images_url'], '/ip.gif" alt="" border="0" />';

		// Show the IP to this user for this post - because you can moderate?
		if ($context['can_moderate_forum'] && !empty($message['member']['ip']))
			echo '
								<a href="', $scripturl, '?action=', !empty($message['member']['is_guest']) ? 'trackip' : 'profile;area=tracking;sa=ip;u=' . $message['member']['id'], ';searchip=', $message['member']['ip'], '">', $message['member']['ip'], '</a> <a href="', $scripturl, '?action=helpadmin;help=see_admin_ip" onclick="return reqWin(this.href);" class="help">(?)</a>';
		// Or, should we show it because this is you?
		elseif ($message['can_see_ip'])
			echo '
								<a href="', $scripturl, '?action=helpadmin;help=see_member_ip" onclick="return reqWin(this.href);" class="help">', $message['member']['ip'], '</a>';
		// Okay, are you at least logged in?  Then we can show something about why IPs are logged...
		elseif (!$context['user']['is_guest'])
			echo '
								<a href="', $scripturl, '?action=helpadmin;help=see_member_ip" onclick="return reqWin(this.href);" class="help">', $txt['logged'], '</a>';
		// Otherwise, you see NOTHING!
		else
			echo '
								', $txt['logged'];

		echo '
							</div>';

		// Are there any custom profile fields for above the signature?
		if (!empty($message['member']['custom_fields']))
		{
			$shown = false;
			foreach ($message['member']['custom_fields'] as $custom)
			{
				if ($custom['placement'] != 2 || empty($custom['value']))
					continue;
				if (empty($shown))
				{
					$shown = true;
					echo '
							<div class="custom_fields_above_signature">
								<ul class="reset nolist">';
				}
				echo '
									<li>', $custom['value'], '</li>';
			}
			if ($shown)
				echo '
								</ul>
							</div>';
		}

		// Show the member's signature?
		if (!empty($message['member']['signature']) && empty($options['show_no_signatures']) && $context['signature_enabled'])
			echo '
							<div class="signature" id="msg_', $message['id'], '_signature">', $message['member']['signature'], '</div>';

		echo '
						</div>
					</div>
					<span class="botslice"><span></span></span>
				</div>';
				
				// Show the Thank You list or the link or.... nothing? XD
		echo '
							<div class="ThankOMatic windowbg" style="display: '.($message['thank_you_post']['isThankYouPost'] ? 'block' : 'none').';" id="ThankOMaticID' . $message['id'] . '">
									<span class="error" id="ErrorThankOMaticID' . $message['id'] . '"></span>';
		// Output the Template for Thank-O-Matic (Normal found in the index.template.php)
		if ($message['thank_you_post']['isThankYouPost'])
		{
			// Mistake? Function not loaded oO.
			if (empty($context['call_thank_you_post_func']))
				loadThankYouTemplateFunctions();

			// Call the correct function =D
			$context['call_thank_you_post_func']($message['thank_you_post'], $message['id']);
		}
		echo '
							</div>';
				
				thank_you_copy();
				
			echo '<hr class="post_separator" />';
	}

	echo '
			</div>
			<a id="lastPost"></a>';
}

function template_main_thank_you_core()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

	// Show the topic information - icon, subject, etc.
	echo '
<div id="forumposts" class="tborder">
	<h3 class="catbg3">
		<img src="', $settings['images_url'], '/topic/', $context['class'], '.gif" align="bottom" alt="" />
		<span>', $txt['author'], '</span>
		<span id="top_subject">', $txt['topic'], ': ', $context['subject'], ' &nbsp;(', $txt['read'], ' ', $context['num_views'], ' ', $txt['times'], ')</span>
	</h3>';

	// These are some cache image buttons we may want.
	// These are some cache image buttons we may want.
	$reply_button = create_button('quote.gif', 'reply_quote', 'quote', 'align="middle"');
	$modify_button = create_button('modify.gif', 'modify_msg', 'modify', 'align="middle"');
	$remove_button = create_button('delete.gif', 'remove_message', 'remove', 'align="middle"');
	$split_button = create_button('split.gif', 'split', 'split', 'align="middle"');
	$thankyoupostpost_button = create_button('thank_you_b.png', 'thank_you_post_post_b', 'thank_you_post_post_b', 'align="middle"');
	$thankyoupostlock_button = create_button('thank_you_lock.png', 'thank_you_post_lock_b', 'thank_you_post_lock_b', 'align="middle"');
	$thankyoupostopen_button = create_button('thank_you_open.png', 'thank_you_post_open_b', 'thank_you_post_open_b', 'align="middle"');
	$thankyoupostdelete_button = create_button('thank_you_delete.png', 'thank_you_post_delete_b', 'thank_you_post_delete_b', 'align="middle"');
	$approve_button = create_button('approve.gif', 'approve', 'approve', 'align="middle"');
	$restore_message_button = create_button('restore_topic.gif', 'restore_message', 'restore_message', 'align="middle"');

	$ignoredMsgs = array();
	$removableMessageIDs = array();

	// AJAX Style Thank You Post
	if (!empty($modSettings['thankYouPostAJAX']))
	{
		echo '
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var thank_you_ajax_url = smf_scripturl + \'?action=thankyouajax;topic=' . $context['current_topic'] . '\';

		function thankyou(msg_id) {
			// Follow the link if no ajax support...
			if (!window.XMLHttpRequest)
				return true;

			// Standard Variables
			var elementName = "ThankOMaticID" + msg_id;
			var elementButton = "buttonThxID" + msg_id;
			var elementLockButton = "thank_lock_button_" + msg_id;
			var elementDeleteButton = "thank_delete_button_" + msg_id;

			// Tell him that something loading :)
			ajax_indicator(true);

			// Remove the Thank You Button :)
			document.getElementById(elementButton).style.display = "none";
			document.getElementById(elementLockButton).style.display = "none";
			document.getElementById(elementDeleteButton).style.display = "none";

			var thank_you_ajax_thx = thank_you_ajax_url + ";sa=thx;msg=" + msg_id;
			var data = ThankYouLoadTextData(thank_you_ajax_thx, elementName, elementButton, elementDeleteButton, elementLockButton);

			return !data;
		}

		function ThankYouLoadTextData(url, elementName, elementButton, elementDeleteButton, elementLockButton) {
			if (!window.XMLHttpRequest)
				return false;

			request = new XMLHttpRequest();
			request.onreadystatechange = function() {
				if (request.readyState != 4)
					return;
				if (request.responseText != null && request.status == 200) {
					if (request.responseText.substr(0, 7) == "#ERROR#") {
						setInnerHTML(document.getElementById("Error" + elementName), request.responseText.substr(7));
						document.getElementById(elementButton).style.display = "inline";
						document.getElementById(elementLockButton).style.display = "none";
						document.getElementById(elementDeleteButton).style.display = "none";
						ajax_indicator(false);
					}
					else {
						document.getElementById(elementName).style.display = "block";
						setInnerHTML(document.getElementById(elementName), request.responseText);
						document.getElementById(elementButton).style.display = "none";
						document.getElementById(elementLockButton).style.display = "inline";
						document.getElementById(elementDeleteButton).style.display = "inline";
						ajax_indicator(false);
					}
					return false;
				}
				else {
					return true;
				}
			}
			// Load the Request!
			request.open("GET", url, true);
			request.send(null);
			return request;
		}
	// ]]></script>';
	}

	// Get all the messages...
	if(!empty($context['thank_you_post']['post']))
	{
		//This is the current message ;) only one currently ;D
		$message = $context['thank_you_post']['post'];
		$is_first_post = !isset($is_first_post) ? true : false;
		$ignoring = false;
		if ($message['can_remove'])
			$removableMessageIDs[] = $message['id'];

		echo '
		<div class="bordercolor">';

		// Are we ignoring this message?
		if (!empty($message['is_ignored']))
		{
			$ignoring = true;
			$ignoredMsgs[] = $message['id'];
		}

		// Show the message anchor and a "new" anchor if this message is new.
		if ($message['id'] != $context['first_message'])
			echo '
			<a id="msg', $message['id'], '"></a>', $message['first_new'] ? '<a id="new"></a>' : '';

		echo '
			<div class="clearfix ', !$is_first_post ? 'topborder ' : '', $message['approved'] ? ($message['alternate'] == 0 ? 'windowbg' : 'windowbg2') : 'approvebg', ' largepadding">';

		// Show information about the poster of this message.
		echo '
				<div class="floatleft poster">
					<h4>', $message['member']['link'], '</h4>
					<ul class="reset smalltext" id="msg_', $message['id'], '_extra_info">';

		// Show the member's custom title, if they have one.
		if (isset($message['member']['title']) && $message['member']['title'] != '')
			echo '
						<li>', $message['member']['title'], '</li>';

		// Show the member's primary group (like 'Administrator') if they have one.
		if (isset($message['member']['group']) && $message['member']['group'] != '')
			echo '
						<li>', $message['member']['group'], '</li>';

		// Don't show these things for guests.
		if (!$message['member']['is_guest'])
		{
			// Show the post group if and only if they have no other group or the option is on, and they are in a post group.
			if ((empty($settings['hide_post_group']) || $message['member']['group'] == '') && $message['member']['post_group'] != '')
				echo '
						<li>', $message['member']['post_group'], '</li>';
			echo '
						<li>', $message['member']['group_stars'], '</li>';

			// Is karma display enabled?  Total or +/-?
			if ($modSettings['karmaMode'] == '1')
				echo '
						<li class="margintop">', $modSettings['karmaLabel'], ' ', $message['member']['karma']['good'] - $message['member']['karma']['bad'], '</li>';
			elseif ($modSettings['karmaMode'] == '2')
				echo '
						<li class="margintop">', $modSettings['karmaLabel'], ' +', $message['member']['karma']['good'], '/-', $message['member']['karma']['bad'], '</li>';

			// Is this user allowed to modify this member's karma?
			if ($message['member']['karma']['allow'])
				echo '
						<li>
							<a href="', $scripturl, '?action=modifykarma;sa=applaud;uid=', $message['member']['id'], ';topic=', $context['current_topic'], '.' . $context['start'], ';m=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $modSettings['karmaApplaudLabel'], '</a>
							<a href="', $scripturl, '?action=modifykarma;sa=smite;uid=', $message['member']['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';m=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $modSettings['karmaSmiteLabel'], '</a>
						</li>';

			// Show online and offline buttons?
			if (!empty($modSettings['onlineEnable']))
				echo '
						<li>', $context['can_send_pm'] ? '<a href="' . $message['member']['online']['href'] . '" title="' . $message['member']['online']['label'] . '">' : '', $settings['use_image_buttons'] ? '<img src="' . $message['member']['online']['image_href'] . '" alt="' . $message['member']['online']['text'] . '" border="0" style="margin-top: 2px;" />' : $message['member']['online']['text'], $context['can_send_pm'] ? '</a>' : '', $settings['use_image_buttons'] ? '<span class="smalltext"> ' . $message['member']['online']['text'] . '</span>' : '', '</li>';

			// Show the member's gender icon?
			if (!empty($settings['show_gender']) && $message['member']['gender']['image'] != '' && !isset($context['disabled_fields']['gender']))
				echo '
						<li>', $txt['gender'], ': ', $message['member']['gender']['image'], '</li>';

			// Show how many posts they have made.
			if (!isset($context['disabled_fields']['posts']))
				echo '
						<li>', $txt['member_postcount'], ': ', $message['member']['posts'], '</li>';

			// Any custom fields for standard placement?
			if (!empty($message['member']['custom_fields']))
			{
				foreach ($message['member']['custom_fields'] as $custom)
					if (empty($custom['placement']) && !empty($custom['value']))
						echo '
						<li>', $custom['title'], ': ', $custom['value'], '</li>';
			}

			// Show some Thank-O-Matic Stats ;D
			if (!empty($modSettings['thankYouPostDisplayPage']) && (empty($modSettings['thankYouPostDisplayDisableBecame']) || empty($modSettings['thankYouPostDisplayDisableMade'])))
			{
				echo '
								<li>', $txt['thank_you_post_thx_display'], '</li>';
				// Disabled?
				if(empty($modSettings['thankYouPostDisplayDisableMade']))
					echo '
								<li>-', $txt['thank_you_post_made_display'], ': ', $message['member']['thank_you_post']['made'], '</li>';

				// Disabled?
				if(empty($modSettings['thankYouPostDisplayDisableBecame']))
					echo '
								<li>-', $txt['thank_you_post_became_display'], ': ', $message['member']['thank_you_post']['became'], '</li>';
			}

			// Show avatars, images, etc.?
			if (!empty($settings['show_user_images']) && empty($options['show_no_avatars']) && !empty($message['member']['avatar']['image']))
				echo '
						<li class="margintop" style="overflow: auto;">', $message['member']['avatar']['image'], '</li>';

			// Show their personal text?
			if (!empty($settings['show_blurb']) && $message['member']['blurb'] != '')
				echo '
						<li class="margintop">', $message['member']['blurb'], '</li>';

			// Any custom fields to show as icons?
			if (!empty($message['member']['custom_fields']))
			{
				$shown = false;
				foreach ($message['member']['custom_fields'] as $custom)
				{
					if ($custom['placement'] != 1 || empty($custom['value']))
						continue;
					if (empty($shown))
					{
						$shown = true;
						echo '
						<li class="margintop">
							<ul class="reset nolist">';
					}
					echo '
								<li>', $custom['value'], '</li>';
				}
				if ($shown)
					echo '
							</ul>
						</li>';
			}

			// This shows the popular messaging icons.
			if ($message['member']['has_messenger'] && $message['member']['can_view_profile'])
				echo '
						<li class="margintop">
							<ul class="reset nolist">
								', !isset($context['disabled_fields']['icq']) && !empty($message['member']['icq']['link']) ? '<li>' . $message['member']['icq']['link'] . '</li>' : '', '
								', !isset($context['disabled_fields']['msn']) && !empty($message['member']['msn']['link']) ? '<li>' . $message['member']['msn']['link'] . '</li>' : '', '
								', !isset($context['disabled_fields']['aim']) && !empty($message['member']['aim']['link']) ? '<li>' . $message['member']['aim']['link'] . '</li>' : '', '
								', !isset($context['disabled_fields']['yim']) && !empty($message['member']['yim']['link']) ? '<li>' . $message['member']['yim']['link'] . '</li>' : '', '
							</ul>
						</li>';

			// Show the profile, website, email address, and personal message buttons.
			if ($settings['show_profile_buttons'])
			{
				echo '
						<li class="margintop">
							<ul class="reset nolist">';
				// Don't show the profile button if you're not allowed to view the profile.
				if ($message['member']['can_view_profile'])
					echo '
								<li><a href="', $message['member']['href'], '">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/icons/profile_sm.gif" alt="' . $txt['view_profile'] . '" title="' . $txt['view_profile'] . '" border="0" />' : $txt['view_profile']), '</a></li>';

				// Don't show an icon if they haven't specified a website.
				if ($message['member']['website']['url'] != '' && !isset($context['disabled_fields']['website']))
					echo '
								<li><a href="', $message['member']['website']['url'], '" title="' . $message['member']['website']['title'] . '" target="_blank" class="new_win">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/www_sm.gif" alt="' . $message['member']['website']['title'] . '" border="0" />' : $txt['www']), '</a></li>';

				// Don't show the email address if they want it hidden.
				if (in_array($message['member']['show_email'], array('yes', 'yes_permission_override', 'no_through_forum')))
					echo '
								<li><a href="', $scripturl, '?action=emailuser;sa=email;msg=', $message['id'], '" rel="nofollow">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt['email'] . '" title="' . $txt['email'] . '" />' : $txt['email']), '</a></li>';

				// Since we know this person isn't a guest, you *can* message them.
				if ($context['can_send_pm'])
					echo '
								<li><a href="', $scripturl, '?action=pm;sa=send;u=', $message['member']['id'], '" title="', $message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline'], '">', $settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/im_' . ($message['member']['online']['is_online'] ? 'on' : 'off') . '.gif" alt="' . ($message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline']) . '" border="0" />' : ($message['member']['online']['is_online'] ? $txt['pm_online'] : $txt['pm_offline']), '</a></li>';

				echo '
							</ul>
						</li>';
			}

			// Are we showing the warning status?
			if ($message['member']['can_see_warning'])
				echo '
						<li>', $context['can_issue_warning'] ? '<a href="' . $scripturl . '?action=profile;area=issuewarning;u=' . $message['member']['id'] . '">' : '', '<img src="', $settings['images_url'], '/warning_', $message['member']['warning_status'], '.gif" alt="', $txt['user_warn_' . $message['member']['warning_status']], '" />', $context['can_issue_warning'] ? '</a>' : '', '<span class="warn_', $message['member']['warning_status'], '">', $txt['warn_' . $message['member']['warning_status']], '</span></li>';
		}
		// Otherwise, show the guest's email.
		elseif (in_array($message['member']['show_email'], array('yes', 'yes_permission_override', 'no_through_forum')))
			echo '
						<li><a href="', $scripturl, '?action=emailuser;sa=email;msg=', $message['id'], '" rel="nofollow">', ($settings['use_image_buttons'] ? '<img src="' . $settings['images_url'] . '/email_sm.gif" alt="' . $txt['email'] . '" title="' . $txt['email'] . '" border="0" />' : $txt['email']), '</a></li>';

		// Done with the information about the poster... on to the post itself.
		echo '
					</ul>
				</div>
				<div class="postarea">
					<div class="flow_hidden">
						<div class="keyinfo">
							<div class="messageicon"><img src="', $message['icon_url'] . '" alt="" border="0"', $message['can_modify'] ? ' id="msg_icon_' . $message['id'] . '"' : '', ' /></div>
							<h5 id="subject_', $message['id'], '">
								<a href="', $message['href'], '" rel="nofollow">', $message['subject'], '</a>
							</h5>
							<div class="smalltext">&#171; <strong>', !empty($message['counter']) ? $txt['reply_noun'] . ' #' . $message['counter'] : '', ' ', $txt['on'], ':</strong> ', $message['time'], ' &#187;</div>
							<div id="msg_', $message['id'], '_quick_mod"></div>
						</div>';

		// If this is the first post, (#0) just say when it was posted - otherwise give the reply #.
		if ($message['can_approve'] || $context['can_reply'] || $message['can_modify'] || $message['can_remove'] || $context['can_split'] || $context['can_restore_msg'])
			echo '
						<ul class="reset smalltext postingbuttons">';

		// Maybe we can approve it, maybe we should?
		if ($message['can_approve'])
			echo '
							<li><a href="', $scripturl, '?action=moderate;area=postmod;sa=approve;topic=', $context['current_topic'], '.', $context['start'], ';msg=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $approve_button, '</a></li>';

		// Can they reply? Have they turned on quick reply?
		if ($context['can_reply'] && !empty($options['display_quick_reply']))
			echo '
							<li><a href="', $scripturl, '?action=post;quote=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';num_replies=', $context['num_replies'], '" onclick="return oQuickReply.quote(', $message['id'], ');">', $reply_button, '</a></li>';

		// So... quick reply is off, but they *can* reply?
		elseif ($context['can_reply'])
			echo '
							<li><a href="', $scripturl, '?action=post;quote=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], ';num_replies=', $context['num_replies'], '">', $reply_button, '</a></li>';

		// Can the user modify the contents of this post?
		if ($message['can_modify'])
			echo '
							<li><a href="', $scripturl, '?action=post;msg=', $message['id'], ';topic=', $context['current_topic'], '.', $context['start'], '">', $modify_button, '</a></li>';

		// How about... even... remove it entirely?!
		if ($message['can_remove'])
			echo '
							<li><a href="', $scripturl, '?action=deletemsg;topic=', $context['current_topic'], '.', $context['start'], ';msg=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_message'], '?\');">', $remove_button, '</a></li>';

		// What about splitting it off the rest of the topic?
		if ($context['can_split'] && !empty($context['num_replies']))
			echo '
							<li><a href="', $scripturl, '?action=splittopics;topic=', $context['current_topic'], '.0;at=', $message['id'], '">', $split_button, '</a></li>';

		// Can do some Thank You Post things :)
		if ($message['thank_you_post']['post'] && !$message['thank_you_post']['locked'])
		{
			echo '
					<li class="thank_you_button"><span id="buttonThxID' . $message['id'] . '" style="display: inline;"><a id="buttonThxHrefID' . $message['id'] . '" href="', $scripturl, '?action=thankyou;topic=', $context['current_topic'], '.0;msg=', $message['id'], '"'.(!empty($modSettings['thankYouPostAJAX']) ? ' onclick="return thankyou(' . $message['id'] . ');"' : '').'>', $thankyoupostpost_button, '</a></span></li>';

			if(!empty($modSettings['thankYouPostAJAX']) && $context['browser']['is_ie']) {
			// I HATE INTERNET EXPLORER!!!!!!!!!!!!!!!!!!!!!!!
			echo '
				<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
					// Rewrite the url :x so that internet explorer can not follow it
					document.getElementById("buttonThxHrefID' . $message['id'] . '").href = "#msg=' . $message['id'] . '";
				// ]]></script>';
			}
		}

		// This is the Thank-O-Matic Lock Button with Ajax special Addon :D
		if ($message['thank_you_post']['lock'] && $message['thank_you_post']['isThankYouPost'])
			echo '
					<li class="', $message['thank_you_post']['locked'] ? 'thank_you_open_button' : 'thank_you_lock_button', '"><a href="', $scripturl, '?action=thankyoupostlock;topic=', $context['current_topic'], '.0;msg=', $message['id'], '">', $message['thank_you_post']['locked'] ? $thankyoupostopen_button : $thankyoupostlock_button, '</a></li>';
		elseif ($message['thank_you_post']['lock'] && !$message['thank_you_post']['isThankYouPost'] && !empty($modSettings['thankYouPostAJAX']) && empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<li class="', $message['thank_you_post']['locked'] ? 'thank_you_open_button' : 'thank_you_lock_button', '" id="thank_lock_button_' . $message['id'] . '" style="display: none;"><a href="', $scripturl, '?action=thankyoupostlock;topic=', $context['current_topic'], '.0;msg=', $message['id'], '">', $message['thank_you_post']['locked'] ? $thankyoupostopen_button : $thankyoupostlock_button, '</a></li>';
		// This will prevent Java Script errors on most browser...
		elseif (!empty($modSettings['thankYouPostAJAX']) || !empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<span id="thank_lock_button_' . $message['id'] . '" style="display: none;"></span>';
		
		// This is the Thank-O-Matic Delete Button with Ajax special Addon ;P
		if ($message['thank_you_post']['delete'] && $message['thank_you_post']['isThankYouPost'])
			echo '
					<li class="thank_you_delete_button"><a href="', $scripturl, '?action=thankyoupostdelete;topic=', $context['current_topic'], '.0;msg=', $message['id'], ';sesc=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_thank_you_post'], '?\');">', $thankyoupostdelete_button, '</a></li>';
		elseif ($message['thank_you_post']['delete'] && !$message['thank_you_post']['isThankYouPost'] && !empty($modSettings['thankYouPostAJAX']) && empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<li class="thank_you_delete_button" id="thank_delete_button_' . $message['id'] . '" style="display: none;"><a href="', $scripturl, '?action=thankyoupostdelete;topic=', $context['current_topic'], '.0;msg=', $message['id'], ';sesc=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_thank_you_post'], '?\');">', $thankyoupostdelete_button, '</a></li>';
		// This will prevent Java Script errors on most browser...
		elseif (!empty($modSettings['thankYouPostAJAX']) || !empty($modSettings['thankYouPostAJAXModButtonsDisable']))
			echo '
					<span id="thank_delete_button_' . $message['id'] . '" style="display: none;"></span>';

		// Can we restore topics?
		if ($context['can_restore_msg'])
			echo '
							<li><a href="', $scripturl, '?action=restoretopic;msgs=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $restore_message_button, '</a></li>';

		// Show a checkbox for quick moderation?
		if (!empty($options['display_quick_mod']) && $options['display_quick_mod'] == 1 && $message['can_remove'])
			echo '
							<li style="display: none;" id="in_topic_mod_check_', $message['id'], '"></li>';

		if ($message['can_approve'] || $context['can_reply'] || $message['can_modify'] || $message['can_remove'] || $context['can_split'] || $context['can_restore_msg'])
			echo '
						</ul>';

		echo '
					</div>';

		// Ignoring this user? Hide the post.
		if ($ignoring)
			echo '
					<div class="ignored" id="msg_', $message['id'], '_ignored_prompt">
						', $txt['ignoring_user'], '
						<a href="#" id="msg_', $message['id'], '_ignored_link" style="display: none;">', $txt['show_ignore_user_post'], '</a>
					</div>';

		// Show the post itself, finally!
		echo '
					<div class="post">
						<hr class="hrcolor" width="100%" size="1" />';

		if (!$message['approved'] && $message['member']['id'] != 0 && $message['member']['id'] == $context['user']['id'])
			echo '
						<div class="approve_post">
							', $txt['post_awaiting_approval'], '
						</div>';
		echo '
						<div class="inner" id="msg_', $message['id'], '"', '>', $message['body'], '</div>
					</div>', $message['can_modify'] ? '
					<img src="' . $settings['images_url'] . '/icons/modify_inline.gif" alt="" title="' . $txt['modify_msg'] . '" class="modifybutton" id="modify_button_' . $message['id'] . '" style="cursor: ' . ($context['browser']['is_ie5'] || $context['browser']['is_ie5.5'] ? 'hand' : 'pointer') . '; display: none;" onclick="oQuickModify.modifyMsg(\'' . $message['id'] . '\')" />' : '';

		// Assuming there are attachments...
		if (!empty($message['attachment']))
		{
			// Now for the attachments, signature, ip logged, etc...
			echo '
					<div id="msg_', $message['id'], '_footer" class="attachments smalltext">';

			$last_approved_state = 1;
			foreach ($message['attachment'] as $attachment)
			{
				// Show a special box for unapproved attachments...
				if ($attachment['is_approved'] != $last_approved_state)
				{
					$last_approved_state = 0;
					echo '
							<fieldset>
								<legend>', $txt['attach_awaiting_approve'], '&nbsp;[<a href="', $scripturl, '?action=attachapprove;sa=all;mid=', $message['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['approve_all'], '</a>]</legend>';
				}

				if ($attachment['is_image'])
				{
					if ($attachment['thumbnail']['has_thumb'])
						echo '
								<a href="', $attachment['href'], ';image" id="link_', $attachment['id'], '" onclick="', $attachment['thumbnail']['javascript'], '"><img src="', $attachment['thumbnail']['href'], '" alt="" id="thumb_', $attachment['id'], '" border="0" /></a><br />';
					else
						echo '
								<img src="' . $attachment['href'] . ';image" alt="" width="' . $attachment['width'] . '" height="' . $attachment['height'] . '" border="0" /><br />';
				}
				echo '
								<a href="' . $attachment['href'] . '"><img src="' . $settings['images_url'] . '/icons/clip.gif" align="middle" alt="*" border="0" />&nbsp;' . $attachment['name'] . '</a> ';

				if (!$attachment['is_approved'])
					echo '
								[<a href="', $scripturl, '?action=attachapprove;sa=approve;aid=', $attachment['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['approve'], '</a>]&nbsp;|&nbsp;[<a href="', $scripturl, '?action=attachapprove;sa=reject;aid=', $attachment['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $txt['delete'], '</a>] ';
				echo '
										(', $attachment['size'], ($attachment['is_image'] ? ', ' . $attachment['real_width'] . 'x' . $attachment['real_height'] . ' - ' . $txt['attach_viewed'] : ' - ' . $txt['attach_downloaded']) . ' ' . $attachment['downloads'] . ' ' . $txt['attach_times'] . '.)<br />';
			}

			// If we had unapproved attachments clean up.
			if ($last_approved_state == 0)
				echo '
							</fieldset>';

			echo '
					</div>';
		}

		// Show the Thank You list or the link or.... nothing? XD
		echo '
							<div class="ThankOMatic" style="display: '.($message['thank_you_post']['isThankYouPost'] ? 'block' : 'none').';" id="ThankOMaticID' . $message['id'] . '">
									<span class="error" id="ErrorThankOMaticID' . $message['id'] . '"></span>';
		// Output the Template for Thank-O-Matic (Normal found in the index.template.php)
		// It will fall back into a standard function, if this template_thank_you_post doesn't exists!
		if ($message['thank_you_post']['isThankYouPost'])
		{
			// Mistake? Function not loaded oO.
			if (empty($context['call_thank_you_post_func']))
				loadThankYouTemplateFunctions();

			// Call the correct function =D
			$context['call_thank_you_post_func']($message['thank_you_post'], $message['id']);
		}
		echo '
							</div>';

		echo '
				</div>
				<div class="moderatorbar">
					<div class="smalltext floatleft" id="modified_', $message['id'], '">';

		// Show "« Last Edit: Time by Person »" if this post was edited.
		if ($settings['show_modify'] && !empty($message['modified']['name']))
			echo '
						&#171; <em>', $txt['last_edit'], ': ', $message['modified']['time'], ' ', $txt['by'], ' ', $message['modified']['name'], '</em> &#187;';

		echo '
					</div>
					<div class="smalltext largepadding floatright">';

		// Maybe they want to report this post to the moderator(s)?
		if ($context['can_report_moderator'])
			echo '
						<a href="', $scripturl, '?action=reporttm;topic=', $context['current_topic'], '.', $message['counter'], ';msg=', $message['id'], '">', $txt['report_to_mod'], '</a> &nbsp;';

		// Can we issue a warning because of this post?  Remember, we can't give guests warnings.
		if ($context['can_issue_warning'] && !$message['is_message_author'] && !$message['member']['is_guest'])
			echo '
						<a href="', $scripturl, '?action=profile;area=issuewarning;u=', $message['member']['id'], ';msg=', $message['id'], '"><img src="', $settings['images_url'], '/warn.gif" alt="', $txt['issue_warning_post'], '" title="', $txt['issue_warning_post'], '" border="0" /></a>';
		echo '
						<img src="', $settings['images_url'], '/ip.gif" alt="" border="0" />';

		// Show the IP to this user for this post - because you can moderate?
		if ($context['can_moderate_forum'] && !empty($message['member']['ip']))
			echo '
						<a href="', $scripturl, '?action=', !empty($message['member']['is_guest']) ? 'trackip' : 'profile;area=tracking;sa=ip;u=' . $message['member']['id'], ';searchip=', $message['member']['ip'], '">', $message['member']['ip'], '</a> <a href="', $scripturl, '?action=helpadmin;help=see_admin_ip" onclick="return reqWin(this.href);" class="help">(?)</a>';
		// Or, should we show it because this is you?
		elseif ($message['can_see_ip'])
			echo '
						<a href="', $scripturl, '?action=helpadmin;help=see_member_ip" onclick="return reqWin(this.href);" class="help">', $message['member']['ip'], '</a>';
		// Okay, are you at least logged in?  Then we can show something about why IPs are logged...
		elseif (!$context['user']['is_guest'])
			echo '
						<a href="', $scripturl, '?action=helpadmin;help=see_member_ip" onclick="return reqWin(this.href);" class="help">', $txt['logged'], '</a>';
		// Otherwise, you see NOTHING!
		else
			echo '
						', $txt['logged'];

		echo '
					</div>';

		// Are there any custom profile fields for above the signature?
		if (!empty($message['member']['custom_fields']))
		{
			$shown = false;
			foreach ($message['member']['custom_fields'] as $custom)
			{
				if ($custom['placement'] != 2 || empty($custom['value']))
					continue;
				if (empty($shown))
				{
					$shown = true;
					echo '
						<div class="custom_fields_above_signature">
							<ul class="reset nolist>';
				}
				echo '
								<li>', $custom['value'], '</li>';
			}
			if ($shown)
				echo '
							</ul>
						</div>';
		}

		// Show the member's signature?
		if (!empty($message['member']['signature']) && empty($options['show_no_signatures']) && $context['signature_enabled'])
			echo '
					<div class="signature" id="msg_', $message['id'], '_signature">', $message['member']['signature'], '</div>';

		echo '
				</div>
			</div>
		</div>';
	}

	echo '
	</div>
</div>
<a name="lastPost"></a>';

}

// Profile Page insert :D, better compatible, is now here!
// Template for showing all the Thank You Posts of the user, in chronological order.
function template_showThankYouPosts()
{
	global $context, $settings, $options, $scripturl, $modSettings, $txt;

	echo '
		<div class="cat_bar"><h3 class="catbg">
			<img src="', $settings['images_url'], '/icons/profile_sm.gif" alt="" />
			', (!isset($context['attachments']) && empty($context['is_topics']) ? $txt['showMessages'] : (!empty($context['is_topics']) ? $txt['showTopics'] : $txt['showAttachments'])), ' - ', $context['member']['name'], '
		</h3></div>
		<div class="pagelinks">', $txt['pages'], ': ', $context['page_index'], '</div>';

	// Button shortcuts
	$quote_button = create_button('quote.gif', 'reply_quote', 'quote', 'align="middle"');
	$reply_button = create_button('reply_sm.gif', 'reply', 'reply', 'align="middle"');
	$remove_button = create_button('delete.gif', 'remove_message', 'remove', 'align="middle"');
	$notify_button = create_button('notify_sm.gif', 'notify_replies', 'notify', 'align="middle"');

	// Are we displaying posts or attachments?
	if (!isset($context['attachments']))
	{
		// For every post to be displayed, give it its own subtable, and show the important details of the post.
		foreach ($context['posts'] as $post)
		{
			echo '
		<div class="topic">
			<div class="title_bar"><h3 class="titlebg">
				<span class="time">', $txt['on'], ': ', $post['time'], '</span>
				<span class="counter">', $post['counter'], '</span>
				<span class="subject"><a href="', $scripturl, '#c', $post['category']['id'], '">', $post['category']['name'], '</a> / <a href="', $scripturl, '?board=', $post['board']['id'], '.0">', $post['board']['name'], '</a> / <a href="', $scripturl, '?topic=', $post['topic'], '.', $post['start'], '#msg', $post['id'], '">', $post['subject'], '</a></span>
			</h3></div>
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
				<div class="post">', $post['body'], '</div>';

			// Show the Thank You list or the link or.... nothing? XD
			echo '
				<div class="ThankOMatic" style="display: '.($post['thank_you_post']['isThankYouPost'] ? 'block' : 'none').';" id="ThankOMaticID' . $post['id'] . '">
						<span class="error" id="ErrorThankOMaticID' . $post['id'] . '"></span>';
			// Output the Template for Thank-O-Matic (Normal found in the index.template.php)
			if ($post['thank_you_post']['isThankYouPost'])
				// This template is inside the index.template.php
				template_thank_you_post($post['thank_you_post'], $post['id']);

			echo '
				</div>';

			echo'
				<div class="middletext mod_icons">';

			if ($post['can_delete'])
				echo '
						<a href="', $scripturl, '?action=profile;u=', $context['current_member'], ';area=showposts;start=', $context['start'], ';delete=', $post['id'], ';', $context['session_var'], '=', $context['session_id'], '" onclick="return confirm(\'', $txt['remove_message'], '?\');">', $remove_button, '</a>';
			if ($post['can_delete'] && ($post['can_mark_notify'] || $post['can_reply']))
				echo '
								', $context['menu_separator'];
			if ($post['can_reply'])
				echo '
						<a href="', $scripturl, '?action=post;topic=', $post['topic'], '.', $post['start'], '">', $reply_button, '</a>', $context['menu_separator'], '
						<a href="', $scripturl, '?action=post;topic=', $post['topic'], '.', $post['start'], ';quote=', $post['id'], ';', $context['session_var'], '=', $context['session_id'], '">', $quote_button, '</a>';
			if ($post['can_reply'] && $post['can_mark_notify'])
				echo '
								', $context['menu_separator'];
			if ($post['can_mark_notify'])
				echo '
						<a href="' . $scripturl . '?action=notify;topic=' . $post['topic'] . '.' . $post['start'] . '">' . $notify_button . '</a>';

			echo '
				</div>
				<span class="botslice"><span></span></span>
			</div>
		</div>';
		}
	}
	else
	{
		echo '
		<table border="0" width="100%" cellspacing="1" cellpadding="2" class="bordercolor" align="center">
			<tr class="titlebg">
				<td width="25%">
					<a href="', $scripturl, '?action=profile;u=', $context['current_member'], ';area=showposts;sa=attach;sort=filename', ($context['sort_direction'] == 'down' && $context['sort_order'] == 'filename' ? ';asc' : ''), '">
						', $txt['show_attach_filename'], '
						', ($context['sort_order'] == 'filename' ? '<img src="' . $settings['images_url'] . '/sort_' . ($context['sort_direction'] == 'down' ? 'down' : 'up') . '.gif" alt="" />' : ''), '
					</a>
				</td>
				<td width="12%" align="center">
					<a href="', $scripturl, '?action=profile;u=', $context['current_member'], ';area=showposts;sa=attach;sort=downloads', ($context['sort_direction'] == 'down' && $context['sort_order'] == 'downloads' ? ';asc' : ''), '">
						', $txt['show_attach_downloads'], '
						', ($context['sort_order'] == 'downloads' ? '<img src="' . $settings['images_url'] . '/sort_' . ($context['sort_direction'] == 'down' ? 'down' : 'up') . '.gif" alt="" />' : ''), '
					</a>
				</td>
				<td width="30%">
					<a href="', $scripturl, '?action=profile;u=', $context['current_member'], ';area=showposts;sa=attach;sort=subject', ($context['sort_direction'] == 'down' && $context['sort_order'] == 'subject' ? ';asc' : ''), '">
						', $txt['message'], '
						', ($context['sort_order'] == 'subject' ? '<img src="' . $settings['images_url'] . '/sort_' . ($context['sort_direction'] == 'down' ? 'down' : 'up') . '.gif" alt="" />' : ''), '
					</a>
				</td>
				<td>
					<a href="', $scripturl, '?action=profile;u=', $context['current_member'], ';area=showposts;sa=attach;sort=posted', ($context['sort_direction'] == 'down' && $context['sort_order'] == 'posted' ? ';asc' : ''), '">
					', $txt['show_attach_posted'], '
					', ($context['sort_order'] == 'posted' ? '<img src="' . $settings['images_url'] . '/sort_' . ($context['sort_direction'] == 'down' ? 'down' : 'up') . '.gif" alt="" />' : ''), '
					</a>
				</td>
			</tr>';

		// Looks like we need to do all the attachments instead!
		$alternate = false;
		foreach ($context['attachments'] as $attachment)
		{
			echo '
			<tr class="', $alternate ? 'windowbg' : 'windowbg2', '">
				<td><a href="', $scripturl, '?action=dlattach;topic=', $attachment['topic'], '.0;attach=', $attachment['id'], '">', $attachment['filename'], '</a></td>
				<td align="center">', $attachment['downloads'], '</td>
				<td><a href="', $scripturl, '?topic=', $attachment['topic'], '.msg', $attachment['msg'], '#msg', $attachment['msg'], '" rel="nofollow">', $attachment['subject'], '</a></td>
				<td>', $attachment['posted'], '</td>
			</tr>';
			$alternate = !$alternate;
		}

		echo '
		</table>';
	}

	// Start the bottom bit.
	echo '
		<table border="0" width="100%" cellspacing="1" cellpadding="4" class="bordercolor" align="center">';

	// No posts? Just end the table with a informative message.
	if ((isset($context['attachments']) && empty($context['attachments'])) || (!isset($context['attachments']) && empty($context['posts'])))
		echo '
			<tr class="windowbg2">
				<td align="center">
					', isset($context['attachments']) ? $txt['show_attachments_none'] : ($context['is_topics'] ? $txt['show_topics_none'] : $txt['show_posts_none']), '
				</td>
			</tr>';

	// Show more page numbers.
	echo '
				<tr>
				<td colspan="3" class="catbg3">
					', $txt['pages'], ': ', $context['page_index'], '
				</td>
			</tr>
		</table>';
}

// Template for the routine maintenance tasks.
function template_maintain_thankYouPost()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

	// If maintenance has finished tell the user.
	if (!empty($context['maintenance_finished']))
		echo '
			<div class="windowbg" style="margin: 1ex; padding: 1ex 2ex; border: 1px dashed green; color: green;">
				', sprintf($txt['maintain_done'], $context['maintenance_finished']), '
			</div>';

	// Starts off with general maintenance procedures.
	echo '
	<table width="100%" cellpadding="4" cellspacing="1" border="0" class="bordercolor">
		<tr class="titlebg">
			<td>', $txt['maintain_thxpostrepair'], '</td>
		</tr>
		<tr class="windowbg">
			<td>
				<form action="', $scripturl, '?action=admin;area=maintainThankYouPost;sa=maintain;activity=optimize" method="post" accept-charset="', $context['character_set'], '">
					<p>', $txt['maintain_thxpostrepair_info'], '</p>
					<p><input type="submit" value="', $txt['maintain_run_now'], '" /></p>
					<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

// Template for the recount maintenance tasks.
function template_maintain_thankYouPost_recount()
{
	global $context, $settings, $options, $txt, $scripturl, $modSettings;

	// If maintenance has finished tell the user.
	if (!empty($context['maintenance_finished']))
		echo '
			<div class="windowbg" style="margin: 1ex; padding: 1ex 2ex; border: 1px dashed green; color: green;">
				', sprintf($txt['maintain_done'], $context['maintenance_finished']), '
			</div>';

	// Starts off with general maintenance procedures.
	echo '
	<table width="100%" cellpadding="4" cellspacing="1" border="0" class="bordercolor">
		<tr class="titlebg">
			<td>', $txt['maintain_thxpostrecount'], '</td>
		</tr>
		<tr class="windowbg">
			<td>
				<form action="', $scripturl, '?action=admin;area=maintainThankYouPost;sa=recount;activity=all" method="post" accept-charset="', $context['character_set'], '">
					<p>', $txt['maintain_thxpostrecount_info'], '</p>
					<p><input type="submit" value="', $txt['maintain_run_now'], '" /></p>
					<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
		<tr class="titlebg">
			<td>', $txt['maintain_thxpostrecount_member'], '</td>
		</tr>
		<tr class="windowbg">
			<td>
				<form action="', $scripturl, '?action=admin;area=maintainThankYouPost;sa=recount;activity=member" method="post" accept-charset="', $context['character_set'], '">
					<p>', $txt['maintain_thxpostrecount_member_info'], '</p>
					<p>', $txt['maintain_thxpostrecount_member_value'], '#<input type="text" name="id_member" id="id_member" size="5"/></p>
					<p><input type="submit" value="', $txt['maintain_run_now'], '" /></p>
					<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
		<tr class="titlebg">
			<td>', $txt['maintain_thxpostrecount_topic'], '</td>
		</tr>
		<tr class="windowbg">
			<td>
				<form action="', $scripturl, '?action=admin;area=maintainThankYouPost;sa=recount;activity=topic" method="post" accept-charset="', $context['character_set'], '">
					<p>', $txt['maintain_thxpostrecount_topic_info'], '</p>
					<p>', $txt['maintain_thxpostrecount_topic_value'], '#<input type="text" name="topic" id="topic" size="5"/></p>
					<p><input type="submit" value="', $txt['maintain_run_now'], '" /></p>
					<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
				</form>
			</td>
		</tr>
	</table>';
}

// The template for Moderator Board Managment ;).
function template_thank_you_show_boards()
{
	global $context, $settings, $options, $scripturl, $txt;
	
	//Some Javascript things ;)
	echo '
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		function selectBoards(ids)
		{
			var toggle = true;

			for (i = 0; i < ids.length; i++)
				toggle = toggle & document.forms.creator["brd" + ids[i]].checked;

			for (i = 0; i < ids.length; i++)
				document.forms.creator["brd" + ids[i]].checked = !toggle;
		}
	// ]]></script>';

	echo '
	<form name="creator" action="', $context['post_url'], '" method="post" accept-charset="', $context['character_set'], '"', !empty($context['force_form_onsubmit']) ? ' onsubmit="' . $context['force_form_onsubmit'] . '"' : '', '>
		<table width="80%" border="0" cellspacing="0" cellpadding="0" class="tborder" align="center">
			<tr>
				<td>
					<table border="0" cellspacing="0" cellpadding="4" width="100%">';

	// Is there a custom title?
	if (isset($context['settings_title']))
		echo '
						<tr class="titlebg">
							<td colspan="3">', $context['settings_title'], '</td>
						</tr>';

	// Have we got some custom code to insert?
	if (!empty($context['settings_message']))
		echo '
						<tr>
							<td class="windowbg2" colspan="3">', $context['settings_message'], '</td>
						</tr>';

	//Load the Boards...
	echo '	
						<tr>
							<td class="windowbg2" colspan="3">
								<fieldset class="windowbg2" style="padding: 10px; margin-left: 5px; margin-right: 5px;">
										<strong>' . $txt['thank_you_post_select_boards'] . '</strong><br />
										<table id="searchBoardsExpand" width="100%" border="0" cellpadding="1" cellspacing="0" align="center" style="margin-top: 1ex;">';

			$alternate = true;
			foreach ($context['board_columns'] as $board)
			{
				if ($alternate)
					echo '
											<tr>';
				echo '
												<td width="50%">';

				if (!empty($board) && empty($board['child_ids']))
					echo '
													<label for="brd', $board['id'], '" style="margin-left: ', $board['child_level'], 'ex;"><input type="checkbox" id="brd', $board['id'], '" name="brd[', $board['id'], ']" value="', $board['id'], '"', $board['is_moderator'] ? ' checked="checked"' : '', ' class="check" />', $board['name'], '</label>';
				elseif (!empty($board))
					echo '
													<a href="javascript:void(0);" onclick="selectBoards([', implode(', ', $board['child_ids']), ']); return false;" style="text-decoration: underline;">', $board['name'], '</a>';

				echo '
												</td>';
				if (!$alternate)
					echo '
											</tr>';

				$alternate = !$alternate;
			}

			echo '
										</table><br />
										<input type="checkbox" name="all" id="check_all" value=""'.($context['all_checked'] ? ' checked="checked"' : '').' onclick="invertAll(this, this.form, \'brd\');" class="check" /><i> <label for="check_all">', $txt['check_all'], '</label></i><br />
									</fieldset> 
								</td>
							</tr>';
			echo '
						<tr>
							<td class="windowbg2" colspan="3" align="center" valign="middle"><input type="submit" value="', $txt['save'], '"', (!empty($context['save_disabled']) ? ' disabled="disabled"' : ''), ' /></td>
						</tr>';

	echo '
					</table>
				</td>
			</tr>
		</table>
		<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '" />
	</form>';
}

// Do not remove the copy is ilegal

function thank_you_copy()
{

 echo '<br /><div align="center"><a href="http://www.smfpersonal.net" target="_blank">Thank-o-Matic 3.0 By Adk Team</a></div>';

}

?>