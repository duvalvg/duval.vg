[center][size=18pt][font=tahoma][b][color=#006666]Thank-o-Matic 3.0 by[/color][/b][/font][/size][/center]

[center][url=http://www.smfpersonal.net/][img]http://www.allmxcars.com/enik/adk-team.png[/img][/url][/center]

[img]http://www.smfpersonal.net/famfamfam/user.png[/img] [b]Autores/Authors:[/b]
     [url=http://www.smfpersonal.net/profiles/enik-u417.html][color=#9A0ABC][b]enik[/b][/color][/url]
     [url=http://www.smfpersonal.net/profiles/heracles-u259.html][color=#9A0ABC][b]^HeRaCLeS^[/b][/color][/url]
     [url=http://www.smfpersonal.net/profiles/lucasruroken-u1.html][color=#9A0ABC][b]lucas-ruroken[/b][/color][/url]

[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Caracter�sticas:[/b]

Con este mod tendras todo un sistema completo de agradecimientos.

Las opciones de este mod se encuentran en:
[i]Admin -> Configuraciones -> Thank-o-Matic[/i]

Copyright 2011 por Adk Team @ visita www.smfpersonal.net/ para soporte oficial. 

Si tu quieres ayudarnos,por favor visita nuestra seccion de contribuciones:
http://www.smfpersonal.net/about.html;sa=contritube-spanish

[hr]
[img]http://www.smfpersonal.net/famfamfam/page_white_flash.png[/img] [b]Features:[/b]

With this mod you will have a complete system of thanks.

The options of this mod are in:
[i]Admin -> Configuration -> Thank-o-Matic[/i]

Copyright 2011 by Adk Team @ visit www.smfpersonal.net/ for official support. 

If you want help, please visit our contributions section:
http://www.smfpersonal.net/about.html;sa=contribute

[hr]
[b]Nueva versi�n:[/b]

  � Imagenes nuevas y pasadas a la extencion .png
  � 100% de compatibilidad con el Hide Tag Special de Adk Team
  � Insetados los lenguajes Spanish es and Latin.
[hr]
[b]New version:[/b]

  � Images refurbished and passed on to extension .png
  � 100% compatibility with the Mod Hide Tag Special of Adk  Team.
  � Added language Spanish es and Latin.
[hr]
[size=10pt][font=tahoma][b]Importante esta version no soporta upgrades.
Ya que es completamente nueva.
[/b][/font][/size]
[hr]
[size=10pt][font=tahoma][b]Note this version does not support upgrades.
It is completely new.
[/b][/font][/size]
[hr]
[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Compatibilidad/Compatibility:[/b]
     SMF 2.0 Gold
     SMF 2.0.1
     SMF 2.0.2

[img]http://www.smfpersonal.net/Themes/default/images/post/topicsolved.gif[/img] [b]Desarrollador/Developer:[/b]

     [url=http://www.smfpersonal.net][b]Adk-Team[/b][/url]