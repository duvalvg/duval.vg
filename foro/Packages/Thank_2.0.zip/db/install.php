<?php
/*******************************************
* Thank-o-matic
* Re-edited by Adk-Team
* www.smfpersonal.net
* 2009-2011
*******************************************/

$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk portal wasn\'t able to conect to smf');
	
//Anothers $smcFunc;
db_extend('packages');

//Hooks Integration
$hooks = array(
	'integrate_pre_include' => '$sourcedir/Subs-ThankYou.php',
	'integrate_actions' => 'ThanYou_add_index_actions',
	'integrate_admin_areas' => 'ThanYou_add_admin_areas',
	'integrate_profile_areas' => 'ThankYou_add_profile_areas',
	'integrate_lucas_profile_modify' => 'ThankYou_add_profile_modify',
	'integrate_display_buttons' => 'ThankYou_add_display_buttons',
);

//Loading....
foreach($hooks AS $hook => $call)
	add_integration_function($hook,$call);

//Creating columns....
$columns = array(
	'id_thx_post' => array(
		'name' => 'id_thx_post',
		'type' => 'int',
		'size' => '10',
		'default' => 0,
		'null' => false,
		'auto' => true,
	),
	'id_msg' => array(
		'name' => 'id_msg',
		'type' => 'int',
		'size' => '10',
		'default' => 0,
		'null' => false,
	),
	'id_topic' => array(
		'name' => 'id_topic',
		'type' => 'mediumint',
		'size' => '8',
		'default' => 0,
		'null' => false,
	),
	'id_board' => array(
		'name' => 'id_board',
		'type' => 'smallint',
		'size' => '5',
		'default' => 0,
		'null' => false,
	),
	'id_member' => array(
		'name' => 'id_member',
		'type' => 'mediumint',
		'size' => '8',
		'default' => 0,
		'null' => false,
	),
	'member_name' => array(
		'name' => 'member_name',
		'type' => 'varchar',
		'size' => '80',
		'null' => false,
	),
	'thx_time' => array(
		'name' => 'thx_time',
		'type' => 'int',
		'size' => '10',
		'default' => 0,
		'null' => false,
	),
);

//Creating indexes...
$indexes = array(
	'id_thx_post' => array(
		'name' => 'id_thx_post',
		'type' => 'primary',
		'columns' => array(
			'id_thx_post' => 'id_thx_post'
		),
	),
	'id_board' => array(
		'name' => 'id_board',
		'type' => 'index',
		'columns' => array(
			'id_board' => 'id_board'
		),
	),
	'id_msg' => array(
		'name' => 'id_msg',
		'type' => 'index',
		'columns' => array(
			'id_msg' => 'id_msg'
		),
	),
	'id_topic' => array(
		'name' => 'id_topic',
		'type' => 'index',
		'columns' => array(
			'id_topic' => 'id_topic'
		),
	),	
	'id_member' => array(
		'name' => 'id_member',
		'type' => 'index',
		'columns' => array(
			'id_member' => 'id_member'
		),
	),
);

$installed = $smcFunc['db_create_table']('{db_prefix}thank_you_post', $columns, $indexes, array(), 'update', 'ignore');

//$sql adds
$sql_adds = array(
	array(
		'table' => "{db_prefix}topics", 
		'colums' => array(
			'thank_you_post_locked' => array(
				'name' => 'thank_you_post_locked',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
				'null' => false,
			),
		),
	),
	array(
		'table' => "{db_prefix}boards", 
		'colums' => array(
			'thank_you_post_enable' => array(
				'name' => 'thank_you_post_enable',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
				'null' => false,
			),
		),
	),
	array(
		'table' => "{db_prefix}messages", 
		'colums' => array(
			'thank_you_post' => array(
				'name' => 'thank_you_post',
				'type' => 'tinyint',
				'size' => '4',
				'default' => 0,
				'null' => false,
			),
			'thank_you_post_counter' => array(
				'name' => 'thank_you_post_counter',
				'type' => 'smallint',
				'size' => '5',
				'default' => 0,
				'null' => false,
			),
		),
	),
	array(
		'table' => "{db_prefix}members", 
		'colums' => array(
			'thank_you_post_made' => array(
				'name' => 'thank_you_post_made',
				'type' => 'mediumint',
				'size' => '8',
				'default' => 0,
				'null' => false,
			),
			'thank_you_post_became' => array(
				'name' => 'thank_you_post_became',
				'type' => 'mediumint',
				'size' => '8',
				'default' => 0,
				'null' => false,
			),
			'last_thank_you_time' => array(
				'name' => 'last_thank_you_time',
				'type' => 'int',
				'size' => '10',
				'default' => 0,
				'null' => false,
			),
		),
	),
);

foreach ($sql_adds as $table) {
	foreach ($table['colums'] as $colum) 
	{
		$updated = $smcFunc['db_add_column']($table['table'], $colum);
	}
}

if($direct_install)
	echo 'Done....';
	
?>