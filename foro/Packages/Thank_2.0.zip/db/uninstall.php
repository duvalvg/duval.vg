<?php
/*******************************************
* Thank-o-matic
* Re-edited by Adk-Team
* www.smfpersonal.net
* 2009-2011
*******************************************/

$direct_install = false;

if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF')){
	require_once(dirname(__FILE__) . '/SSI.php');
	$direct_install = true;
}
elseif (!defined('SMF'))
	die('Adk portal wasn\'t able to conect to smf');
	
//Anothers $smcFunc;
db_extend('packages');

//Hooks Integration
$hooks = array(
	'integrate_pre_include' => '$sourcedir/Subs-ThankYou.php',
	'integrate_actions' => 'ThanYou_add_index_actions',
	'integrate_admin_areas' => 'ThanYou_add_admin_areas',
	'integrate_profile_areas' => 'ThankYou_add_profile_areas',
	'integrate_lucas_profile_modify' => 'ThankYou_add_profile_modify',
	'integrate_display_buttons' => 'ThankYou_add_display_buttons',
);

//Loading....
foreach($hooks AS $hook => $call)
	remove_integration_function($hook,$call);

$drop_tables = array(
	'thank_you_post',
);

foreach($drop_tables AS $table)
	$smcFunc['db_drop_table']('{db_prefix}'.$table, array(), 'ignore');

$drops = array(
	'topics' => 'thank_you_post_locked',
	'boards' => 'thank_you_post_enable',
	'messages' => 'thank_you_post',
	'messages' => 'thank_you_post_counter',
	'members' => 'thank_you_post_made',
	'members' => 'thank_you_post_became',
	'members' => 'last_thank_you_time',
);

foreach($drops AS $table => $column)
	$smcFunc['db_remove_column']('{db_prefix}'.$table, $column, array(), 'ignore');
	
if($direct_install)
	echo'Done....';
	
?>