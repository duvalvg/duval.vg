[center][color=blue][size=16px][color=green]Quick Moderation on Quick Reply v1.1.2 - NIBOGO
[/color][/size][/color][color=green]Add two simple ways to lock/unlock and sticky/non-sticky topics on quick moderation.
[/color][/center]
[hr]
[center][url=http://www.simplemachines.org/community/index.php?topic=238198.0][b]Support topic[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?mod=1175][b]Link to Mod[/b][/url] | [url=http://custom.simplemachines.org/mods/index.php?action=search;author=126412][b]My Mods[/b][/url] | [url=http://www.smfpacks.com/][b]Website[/b][/url][/center] | [url=http://www.smfpacks.com/donate.php][b]Donate[/b][/url][/center] 
[hr]
[b]
Author[/b]:
- NIBOGO

[b]Features[/b]:
o Can set a top�c as locked/unlocked with a simple checkbox on quick reply.
o Can set a top�c as sticky/un-sticky with a simple checkbox on quick reply.
o Quick way to moderate topics, you can moderate and reply in one click.

[b]Languages[/b]:
- All the Languages!

[b]Compatibility[/b]:
- 1.1.X
- 2.0

[hr]
[size=16px]Changelogs:[/size]

[b]1.1.2 - 08 Mar 2010[/b]
o Added support for SMF 2.0 RC3.

[b]1.1 - 22 Nov 2009[/b]
o Added support for SMF 2.0 RC2.

[b]1.1 - 08 Oct 2009[/b]
o Added support for SMF 1.1.10.

[b]1.0 - 31 May 2009[/b]
o Initial release.