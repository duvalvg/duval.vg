<?php
if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
else if(!defined('SMF'))
	die('<b>Error:</b> Cannot upgrade - please verify you placed this file in the same folder as SMF\'s index.php and SSI.php files.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

db_extend('packages');

// Just-in-case fix. Make sure any bugged field reverts back
$smcFunc['db_change_column'](
	'{db_prefix}messages', 
	'gpbp_score',
	array(
		'name' => 'gpbp_score',
		'type' => 'smallint',
		'size' => 6,
		'null' => false,
		'default' => 0,
		'unsigned' => false,
	),
	'ignore');
$smcFunc['db_change_column'](
	'{db_prefix}messages', 
	'gpbp_respect',
	array(
		'name' => 'gpbp_respect',
		'type' => 'smallint',
		'size' => 6,
		'null' => false,
		'default' => 0,
		'unsigned' => false,
	),
	'ignore');

// I'm sorry SMF, but this table needs an extra column!
$gpbp_columns = $smcFunc['db_list_columns']('{db_prefix}log_gpbp');
// ... doesn't it?
if (! in_array('log_time', $gpbp_columns))
{
	$smcFunc['db_add_column']('{db_prefix}log_gpbp',
		array(
			'name' => 'log_time',
			'type' => 'int',
			'size' => 10,
			'null' => false,
			'unsigned' => true,
			'default' => 0
		),
		array(),
		'ignore'
	);
	// Since we don't know when these old votes were casted, guess it was just now!
	$smcFunc['db_query']('','
		UPDATE {db_prefix}log_gpbp
		SET log_time = '. time()
	); 
}
unset($gpbp_columns);

// Finally, add some (brand new!) default settings.
$smcFunc['db_insert']('ignore',
	'{db_prefix}settings',
	array(
		'variable' => 'string',
		'value' => 'string'
	),
	array(
		array('gpbp_users_hide_again', '0'),
		array('gpbp_voters_list_limit', '0'),
		array('gpbp_disable_negative_voting', '0'),
		array('gpbp_disable_disrespect', '0'),
		array('gpbp_post_count_limit', '0'),
		array('gpbp_show_best_topics', '0'),
		array('gpbp_button_set', ''),
	),
	array('variable')
);

if(SMF == 'SSI')
	echo 'Finished updating the database. Please delete this file.';
?>