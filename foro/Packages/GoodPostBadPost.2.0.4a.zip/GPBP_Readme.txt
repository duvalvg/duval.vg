[center][size=5][b]Good Post/Bad Post Mod[/b][/size]
Author: [b]OutofOrder[/b]
Mod Version: [b]2.0.4[/b]
SMF Versions supported: [b]2.0 RC3, 2.0 RC4[/b]

[size=11pt]This Mod will add post voting to your forum in a user-moderated fashion. The outcome is a bit of help to the forum moderators, with the nice extra that it resembles democracy a little. [i]It gives members and moderators a general idea of who's a worthy poster and who isn't.[/i][/size]
[/center]

[size=3][b]Setting it up ([color=red]please read[/color]).[/b][/size]
Right after this mod is installed successfully, you might want to...
[list type=decimal]
[li][b]Choose which membergroups will be able to vote posts[/b], and which will be able to display hidden posts. You can do this in the [b]Permissions[/b] area.[/li]
[li]Choose which boards will have this mod enabled. You can do this by going to [b]Forums -> Good Post/Bad Post -> Basic settings[/b] inside the Admin panel.[/li]
[li]Decide the [i]Bad post threshold[/i]. This setting should be different from community to community, so don't worry if you think the value may be wrong at first. It's about trial and error.[/li]
[li]Decide if you will restrict voting to members with a minimum post count, or if you will restrict votes only to positive scores. You can find these options in the [b]Advanced configuration[/b] tab.[/li]
[li]Choose which staff membergroup will be able to manage this mod. This permission can be found under [b]Forum administration[/b] permissions.[/li] 
[/list]
[size=3]
[b]The installer fails to modify one of your themes?[/b][/size]
If you can't apply this mod to one of your existing themes automatically, [b]don't panic![/b]
This mod was written in order to be easily added to custom themes. Doing so should be possible to achieve if you know a bit of PHP, and are able to understand the theme's HTML code base.
Please visit the [b][url=http://www.simplemachines.org/community/index.php?topic=318290.0]GP/BP mod official thread[/url][/b] in order to learn more about installing this mod in custom themes. 
