[center][size=4]You are about to [i]upgrade[/i] the Good Post/Bad Post Mod[/size]
New Mod Version: [b]2.0.4[/b]
SMF Versions supported: [b]2.0 RC3, 2.0 RC4[/b]
[/center]

Now supporting SMF 2.0 RC4.
The mod was fully translated to Russian. Special thanks to Bugo who provided the translations. 
 