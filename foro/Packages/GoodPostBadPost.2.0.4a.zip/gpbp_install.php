<?php
if(file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
else if(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you placed this file in the same folder as SMF\'s index.php and SSI.php files.');

if((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin priveleges required.');

db_extend('packages');

// New table: Vote tracking.
$smcFunc['db_create_table']('{db_prefix}log_gpbp',
	array(
		array(
			'name' => 'id_msg',
			'type' => 'int',
			'size' => 10,
			'unsigned' => true,
			'null' => false
		),
		array(
			'name' => 'id_member',
			'type' => 'mediumint',
			'size' => 8,
			'unsigned' => true,
			'null' => false
		),
		array(
			'name' => 'score',
			'type' => 'smallint',
			'size' => 2,
			'null' => false
		),
		array(
			'name' => 'id_poster',
			'type' => 'mediumint',
			'size' => 8,
			'unsigned' => true,
			'null' => false
		),
		array(
			'name' => 'log_time',
			'type' => 'int',
			'size' => 10,
			'unsigned' => true,
			'null' => false
		),
	),
	array(
		array(
			'type' => 'index',
			'columns' => array('id_member'),
		),
		array(
			'type' => 'index',
			'columns' => array('id_poster'),
		),
		array(
			'type' => 'primary',
			'columns' => array('id_msg', 'id_member'),
		),
	),
	array(),
	'update');

// I'm sorry SMF, but some tables need extra columns!
// For instance, the vote count per message.
$smcFunc['db_add_column']('{db_prefix}messages',
	array(
		'name' => 'gpbp_score',
		'type' => 'smallint',
		'size' => 6,
		'null' => false,
		'unsigned' => false,
		'default' => 0
	),
	array(),
	'ignore'
);

// Or the Respect count per member.
$smcFunc['db_add_column']('{db_prefix}members',
	array(
		'name' => 'gpbp_respect',
		'type' => 'smallint',
		'size' => 6,
		'null' => false,
		'unsigned' => false,
		'default' => 0
	),
	array(),
	'ignore'
);

// Or the mod switch per board.
$smcFunc['db_add_column']('{db_prefix}boards',
	array(
		'name' => 'enable_gpbp',
		'type' => 'tinyint',
		'size' => 1,
		'null' => false,
		'default' => 0
	),
	array(),
	'ignore'
);

// Finally, add some default settings.
$smcFunc['db_insert']('ignore',
	'{db_prefix}settings',
	array(
		'variable' => 'string',
		'value' => 'string'
	),
	array(
		array('gpbp_hide_threshold', '-5'),
		array('gpbp_display_respect', '1'),
		array('gpbp_display_stats', '1'),
		array('gpbp_users_choice', '1'),
		array('gpbp_users_choice_none', '0'),
		array('gpbp_users_hide_again', '0'),
		array('gpbp_voters_list_limit', '0'),
		array('gpbp_disable_negative_voting', '0'),
		array('gpbp_disable_disrespect', '0'),
		array('gpbp_post_count_limit', '0'),
		array('gpbp_show_best_topics', '0'),
		array('gpbp_button_set', ''),
	),
	array('variable')
);

if(SMF == 'SSI')
	echo 'Finished updating the database. Please delete this file.';
?>